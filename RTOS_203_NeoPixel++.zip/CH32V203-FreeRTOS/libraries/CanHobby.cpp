/*
 * Art.cpp
 *
 *  Created on: Sep. 2, 2023
 *      Author: moun
 */

#include "CanHobby.h"

CanHobby::CanHobby() {
	// TODO Auto-generated constructor stub

}

CanHobby::~CanHobby() {
	// TODO Auto-generated destructor stub
}

int CanHobby::getArr( int idx ) {
	return arr[ idx ];
}




