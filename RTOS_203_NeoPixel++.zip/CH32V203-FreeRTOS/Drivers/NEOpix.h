/*
 * NEOpix.h
 *  Created on: Dec. 26, 2023
 *      Author: CanHobby
 */

#ifndef DRIVERS_NEOPIX_H_
#define DRIVERS_NEOPIX_H_

#include "inttypes.h"
#include "ch32v20x.h"

#define RED     0x000F00    // GRB
#define GREEN   0x0F0000
#define BLUE    0x00000F
#define YELLOW  0x070500
#define MAGENTA 0x000507
#define CYAN    0x070007
#define BLACK   0x000000
#define WHITE   0x050505
// #define NUM     7

#define Zero GPIOB->BSHR = _pin_num; \
		__NOP(); __NOP(); __NOP(); __NOP(); \
    	__NOP(); __NOP(); __NOP(); __NOP(); \
    	__NOP(); __NOP(); __NOP(); __NOP(); \
    	__NOP(); __NOP(); __NOP();  \
    	GPIOB->BCR = _pin_num; \
    	__NOP(); __NOP(); __NOP(); __NOP(); \
    	__NOP(); __NOP(); __NOP(); __NOP(); \
    	__NOP(); __NOP(); __NOP(); __NOP(); \
    	__NOP(); __NOP(); __NOP(); __NOP(); \
    	__NOP(); __NOP(); __NOP(); __NOP(); \
    	__NOP(); __NOP(); __NOP(); __NOP();

//	printf("One pin_num = 0x%X\n", _pin_num );
#define One GPIOB->BSHR = _pin_num; \
		__NOP(); __NOP(); __NOP(); __NOP(); \
    	__NOP(); __NOP(); __NOP(); __NOP(); \
    	__NOP(); __NOP(); __NOP(); __NOP(); \
    	__NOP(); __NOP(); __NOP(); __NOP(); \
    	__NOP(); __NOP(); __NOP(); __NOP(); \
    	__NOP(); __NOP(); __NOP(); __NOP(); \
    	__NOP(); __NOP(); __NOP(); __NOP(); \
    	__NOP(); __NOP(); __NOP(); __NOP(); \
    	__NOP(); __NOP(); __NOP(); __NOP(); \
    	__NOP(); __NOP();  \
    	GPIOB->BCR = _pin_num; \
		__NOP(); __NOP(); \
    	__NOP(); __NOP(); __NOP(); __NOP(); \
    	__NOP(); __NOP(); __NOP(); __NOP(); \
//    	__NOP(); __NOP(); __NOP();

class NEOpix{
public:
	NEOpix( int num_pix, uint32_t pin );
	virtual ~NEOpix();
	void Refresh( );
	void Clear( int32_t color );

	uint32_t buff[45];
	uint32_t Colors[16] = { BLUE, RED, YELLOW, MAGENTA, GREEN, CYAN, BLACK, WHITE, BLACK, BLACK, BLACK, BLACK, BLACK, BLACK, BLACK, BLACK };
private:
//	uint32_t Data;
	uint32_t _pin;
	uint16_t _pin_num;
	int _num_pixs;
//	int PCnt;

	friend class NEOseg;
};

class NEOseg {
public:
	NEOseg( int offset, uint16_t length, NEOpix& np );  //   int ofst, uint16_t len, uint32_t *buff );
	virtual ~NEOseg();
	void Install( );
	void Fill( int32_t color );
	void Run( bool up, bool down = false );
	void Fade( int32_t color, bool up = true, bool down = false );
	void Twinkle( );
	uint32_t fcolor, fade_inc, *cols;

//private:
	int ofst;
	uint16_t len;
	uint32_t *strip;
	uint32_t arr[ 45 ];
private:
	int _idx;

};


#endif /* DRIVERS_NEOPIX_H_ */
