/*
 * NEOpix.cpp
 *
 *  Created on: Dec. 26, 2023
 *      Author: moun
 */
#include "FreeRTOS.h"
#include "task.h"
#include <NEOpix.h>
#include <cmath>
#include <string.h>

NEOseg::NEOseg( int offset, uint16_t length, NEOpix& np ) {
	ofst = offset; len=length; _idx = 0; strip = np.buff; cols = np.Colors;
};

NEOseg::~NEOseg() {}

void NEOseg::Twinkle( ) { // int32_t color, bool up, bool down ) {
	static int x;

//	printf("len = %X, rand = %X\n", len, rand() % len );

//	for( x=ofst; x<len+ofst; x++ ) {
		arr[ rand() % len ] = cols[ rand() & 15 ];
//		arr[ cols[ rand() & 7 ];
//	}
//	fcolor += fade_inc;
//	if( fcolor > 0x2F2F2F ) fcolor = fade_inc;
//	printf("fc = %04X\n", fcolor );
	Install();
}

void NEOseg::Fade( int32_t color, bool up, bool down ) {
	static int x;

	for( x=ofst; x<len+ofst; x++ ) {
		arr[x] = fcolor;
	}
	fcolor += fade_inc;
	if( fcolor > 0x2F2F2F ) fcolor = fade_inc;
//	printf("fc = %04X\n", fcolor );
	Install();
}

void NEOseg::Run( bool up, bool down ) {

//	printf("Run: buff[1] = %d\n", strip->buff[1] );
//	extern uint32_t Colours[8];
	if( up ) {
	  for( _idx=ofst; _idx<len+ofst; _idx++ ) {
		arr[ _idx ] = cols[ rand() & 7 ];
		Install( );
	    vTaskDelay( 30 );
	    arr[ _idx ] = BLACK;
		Install( );
			}  //  end of up for
		}
	if( down ) {
		  for( _idx=len+ofst; _idx>ofst; _idx-- ) {
			arr[ _idx ] = cols[ rand() & 7 ];
			Install( );
		    vTaskDelay( 30 );
		    arr[ _idx ] = BLACK;
			Install( );
				}  //  end of down for
	  }
}

void NEOseg::Fill( int32_t color ) {
//	printf("Fill with %d %Xs\n", len, color );
	static int x;
	for( x=ofst; x<len+ofst; x++ ) arr[x] = color;
	Install( );
}

void NEOseg::Install( ) {
// printf("Install ofst = %d, len = %d, dest = %X\n", ofst, len, strip );
	memcpy( strip+ofst, arr+ofst, len * 4 );
// printf("arr = %X %X -- buff = %X %X\n\n", arr[0], arr[1], strip[0], strip[1] );
}

NEOpix::NEOpix( int num_pix, uint32_t pin ) {
	_pin = pin;
	_pin_num = 1 << (pin & 0xFFFF);
	_num_pixs = num_pix;
}

NEOpix::~NEOpix() { }

void NEOpix::Clear( int32_t color ) {

int BCnt;
int pix_cnt = _num_pixs;
uint32_t Data;

// printf("Clear pix_cnt = %d, color = %06X\n", pix_cnt, color );

	while( pix_cnt-- ) {
		Data = color;
		BCnt = 24;
	    while( BCnt-- ) {
//	    	printf("D = %06X\n", Data );
	if( Data & 0x800000 ) { One; } else { Zero; };
	Data = Data << 1;
	    	}

	    }
	Delay_Us( 170 );
//	vTaskDelay( 15 );
}

void NEOpix::Refresh( ) {

int pix_cnt = _num_pixs;
uint32_t Data;
int BCnt;

// printf("Refresh cnt = %d, pixbuff = %X\n", pix_cnt, buff );
// for( int i =0; i<8; i++ ) printf("%X:",buff[i] );
// printf("\n");
while( pix_cnt-- ) {
	Data = buff[ _num_pixs - pix_cnt - 1];
// printf("Data = 0x%06X\n", Data );
	BCnt = 24;
    while( BCnt-- ) {
//    	printf("D = %06X:", Data );
if( Data & 0x800000 ) { One; } else { Zero; };
Data = Data << 1;

    	}
    }
// printf("\n");
 vTaskDelay( 5 );
//Delay_Us( 70 );
}

