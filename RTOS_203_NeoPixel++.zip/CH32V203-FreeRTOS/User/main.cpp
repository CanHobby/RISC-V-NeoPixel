/********************************** (C) COPYRIGHT *******************************
 * File Name          : main.cpp
 * Author             : CanHobby.ca
 * Version            : V1.0.0
 * Date               : 2023/09/25
 * Description        : Main program body.
**************************************************************************/

#include "debug.h"
#include "NEOpix.h"
#include "FreeRTOS.h"
#include "task.h"
#include "CHobbyGPIO.h"
#include <cmath>

/* Global define */
#define REFRESH_PRIO     5
#define REFRESH_SIZE     456
#define ANIM_PRIO 		 2
#define ANIM_STK_SIZE    456

#define MAX_LEDS		45
/* Global Variable */

CHobby_GPIO gpio;
NEOpix strip1( 45, B15 );
NEOpix strip2( 15, B11 );
NEOseg seg1( 0,  20, strip1 );
NEOseg seg2( 21, 20, strip1 );
NEOseg seg3( 0,  15, strip2 );

// uint32_t Buf1[ MAX_LEDS ]; // Refresh Buffer #1
// uint32_t Buf2[ 15 ]; // Refresh Buffer #2

uint32_t Colours[8] = { BLUE, RED, YELLOW, MAGENTA, GREEN, CYAN, BLACK, WHITE };
//, BLACK, BLACK, BLACK, BLACK, BLACK, BLACK };

uint32_t Strip1[ 6 ] = { GREEN, BLUE, GREEN, BLUE, BLACK, GREEN };

uint32_t Strip2[ 8 ] = { WHITE, RED, BLUE, GREEN, BLUE, YELLOW, MAGENTA, CYAN };

TaskHandle_t Refresh_Handle;
TaskHandle_t Anim_Handle;
TaskHandle_t Anim2_Handle;

uint32_t C_Color = BLUE;


void Refresh_tk(void *pvParameters)
{
//    printf("Refresh entry\r\n");
//    gpio.pinMode( A0, OUTPUT, 0x05 );
//    int x = 6;
//    vTaskDelay( 2250 );
    while(1)
    {
//        printf("Refresh\r\n");
//        gpio.toggle( A0 );
        strip1.Refresh( );
        strip2.Refresh( );
        vTaskDelay( 12 );
    }
}

/******************************************************************/

void Anim_tk(void *pvParameters)
{
//	printf("Anim entry\r\n");
// static int idx, y = 0;
// bool up = false, down = false;
// rand_r( &seed );
// uint32_t ctmp = 0;

// seg1.Fill( MAGENTA );
    seg1.fcolor = 0x10000;
    seg1.fade_inc = 0x10000;
    while(1)
    {
        vTaskDelay( 10 );

//        seg1.Fade( 0x101 );
//        seg1.Fill( MAGENTA ); // Colours[ rand() & 7 ] );
//        seg2.Fill( BLUE );  //  Colours[ rand() & 7 ] );
    	seg3.Twinkle( );
    	seg2.Run( true );
/***
if( up ) {
  for( idx=0; idx<seg1._len; idx++ ) {
	seg1._arr[ idx] = Colours[ rand() & 7 ];
	seg1.Install( Buf1 );
    vTaskDelay( 30 );
    seg1._arr[ idx] = BLACK;
//    seg1._arr[ idx + 5] = BLACK;
	seg1.Install( Buf1 );
		}  //  end of up for
  }
/**** /
if( down ) {
for( idx=seg1._len-1; idx>-1; idx-- ) {
	seg1.arr[ idx] = Colours[ rand() & 7 ];
	seg1.Install( Buf1 );
    vTaskDelay( 30 );
    seg1._arr[ idx] = BLACK;
//    seg1._arr[ idx + 5] = BLACK;
	seg1.Install( Buf1 );
		}  //  end of down for
   }  ****/
    }	//  end of forever loop for this task
}	// end of Animation Task


void Anim2_tk(void *pvParameters)
{
//	printf("Anim entry\r\n");
// static int idx, y = 0;
// bool up = false, down = false;
// rand_r( &seed );
// uint32_t ctmp = 0;

// seg1.Fill( MAGENTA );
//    seg1.fcolor = 0x10000;
//    seg1.fade_inc = 0x10000;
    while(1)
    {
        vTaskDelay( 20 );

//        seg1.Fade( 0x101 );
//        seg1.Fill( MAGENTA ); // Colours[ rand() & 7 ] );
//        seg2.Fill( BLUE );  //  Colours[ rand() & 7 ] );
    	seg3.Twinkle( );

    }
}

/*********************************************************************
 * @fn      main
*/

int main(void)
{
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
    Delay_Init();
    USART_Printf_Init(115200);
    printf("\n\nSysClk = %d MHz\r\n", SystemCoreClock / 1000000);

    gpio.pinMode( A0,  OUTPUT, 0x05 );
    gpio.pinMode( B11, OUTPUT, 0x8800 );

//    strip1.buff[1] = 69;
    strip1.Clear( BLACK );   Delay_Ms( 1400 );
    strip2.Clear( BLACK );   Delay_Ms( 1400 );
//    strip2.Clear( BLACK );     Delay_Ms( 1400 );
//    strip1.Clear( BLACK );     Delay_Ms( 1400 );
//    strip1.Refresh( Strip1 );  Delay_Ms( 1400 );
//    strip2.Refresh( Strip2 );  Delay_Ms( 1400 );
// printf("strp1 = %X\n", strip1.buff[1]);
//seg1.Fill( MAGENTA );
//seg1.Install( Clear );
seg2.Fill( BLUE );

    /* create two task */
/****/
    xTaskCreate((TaskFunction_t )Anim_tk,
                        (const char*    )"ANim",
                        (uint16_t       )ANIM_STK_SIZE,
                        (void*          )NULL,
                        (UBaseType_t    )ANIM_PRIO,
                        (TaskHandle_t*  )&Anim_Handle);

    xTaskCreate((TaskFunction_t )Anim2_tk,
                        (const char*    )"ANim",
                        (uint16_t       )ANIM_STK_SIZE,
                        (void*          )NULL,
                        (UBaseType_t    )ANIM_PRIO,
                        (TaskHandle_t*  )&Anim2_Handle);

    xTaskCreate((TaskFunction_t )Refresh_tk,
                    (const char*    )"task1",
                    (uint16_t       )REFRESH_SIZE,
                    (void*          )NULL,
                    (UBaseType_t    )REFRESH_PRIO,
                    (TaskHandle_t*  )&Refresh_Handle);
/*****/

    vTaskStartScheduler();

    while(1)
    {
        printf("Shouldn't get here!!\n");
        Delay_Ms( 10000 );
    }
}

