/********************************** (C) COPYRIGHT *******************************
 * File Name          : main.c
 * Author             : CanHobby.ca
 * Date               : 2023/11/01
 * Description        : Main program body for SPI NeoPixel demo.
 *********************************************************************************

 *@Note
 *single wire half duplex master mode NEOPixel strip driver.
 *Master: SPI1_MOSI(PA7) connects to NEO Pixel DataIn. (SPI1_SCK(PA5) not used)
 *********************************************************************************/

#include "debug.h"
#include "string.h"
#include "ch32v20x_spi.h"

/* Global define */

/* Global Variable */
//  Used for Interrupt mode - not used in Polled Mode
volatile uint8_t TxCnt=0;
volatile uint8_t TxBufSize=0;
uint8_t *TxData;
u8 RxData[Size];

/*********************************************************************
 * @fn      sendSPIbufZT
 * @brief   send Zero Terminated buffer via SPI in half-duplex.
 * @params  uint8_t *buf -- 8 bit Zero Terminated buffer to Transmit
 * @return  none
 */
void sendSPIbufZT( uint8_t *buf )
{

while( *buf ) {
	while( (SPI1->STATR & 0x0080 ) );  // we Poll the BSY flag on the SPI 1
		SPI1->DATAR = *buf++;		   // then put the buff data into the SPI data register
//		printf( "%X ", *buf++ );
				}
// printf("\n");
}

void sendSPIwrds( uint16_t buf[5] )
{
uint8_t x = 0;

while( x < 5 ) {
	while( (SPI1->STATR & 0x0080 ) );
		SPI1->DATAR = buf[x++];
//		printf("%04X ", buf[x-1] );
				}
//  printf("\n");
}

/*********************************************************************
 * @fn      SPI_1Lines_HalfDuplex_Init
 * @brief   Configuring the SPI for half-duplex communication.
 * @return  none
 */
void SPI_1Lines_HalfDuplex_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure={0};
	SPI_InitTypeDef SPI_InitStructure={0};
	NVIC_InitTypeDef NVIC_InitStructure={0};

	RCC_APB2PeriphClockCmd( RCC_APB2Periph_GPIOA | RCC_APB2Periph_SPI1, ENABLE );

// #if (SPI_MODE == HOST_MODE)

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init( GPIOA, &GPIO_InitStructure );

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init( GPIOA, &GPIO_InitStructure );
/**
#elif (SPI_MODE == SLAVE_MODE)
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_Init( GPIOA, &GPIO_InitStructure );

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_Init( GPIOA, &GPIO_InitStructure );
#endif
***/

#if (SPI_MODE == HOST_MODE)
	SPI_InitStructure.SPI_Direction = SPI_Direction_1Line_Tx;
	SPI_InitStructure.SPI_Mode = SPI_Mode_Master;

#elif (SPI_MODE == SLAVE_MODE)
	SPI_InitStructure.SPI_Direction = SPI_Direction_1Line_Rx;
	SPI_InitStructure.SPI_Mode = SPI_Mode_Slave;

#endif

	SPI_InitStructure.SPI_DataSize = SPI_DataSize_8b;
	SPI_InitStructure.SPI_CPOL = SPI_CPOL_Low;
	SPI_InitStructure.SPI_CPHA = SPI_CPHA_1Edge;
	SPI_InitStructure.SPI_NSS = SPI_NSS_Soft;
	SPI_InitStructure.SPI_BaudRatePrescaler = SPI_BaudRatePrescaler_16;
	SPI_InitStructure.SPI_FirstBit = SPI_FirstBit_MSB;
	SPI_InitStructure.SPI_CRCPolynomial = 7;  //  7;
	SPI_Init( SPI1, &SPI_InitStructure );

	NVIC_InitStructure.NVIC_IRQChannel = SPI1_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);

	SPI_Cmd( SPI1, ENABLE );
}

uint16_t data16[6];

uint16_t *enc_NEO16( uint32_t n ) {

	uint8_t  idx=0, q=5;
//	uint16_t t16;

	for( idx = 0; idx < 6; idx++ ) data16[idx] = 0;
	idx = 0;

	printf("enc_NEO recvd 0x%08X\n\n", n );
	while ( q-- ) {
	    if (n & (1) ) {
	    	printf("m4 = %d:%x ", idx % 5, 6<<((idx % 4)*3) );
	    	data16[ 0 ] |= 6<<((idx % 5)*3);
	    }
	    else {
	        printf("m4 = %d:%x ", idx % 5, 4<<((idx % 4)*3) );
	        data16[ 0 ] |= 4<<((idx % 5)*3);
	    	}
	    idx++;
	    n >>= 1;
	}

  printf("0x%04X\n", data16[0]);
  return data16;

}

void enc_NEO8( uint32_t n, uint8_t buf[24] ) {

	uint8_t  idx=0, q=0;
//	uint16_t t16;

	for( idx = 0; idx < 24; idx++ ) buf[idx] = 0;
	idx = 0;

//	printf("enc_NEO recvd 0x%08X\n\n", n );
	while ( q<24 ) {
	    if (n & (1) ) {
//	    	printf("m4 = %d:%x ", idx % 5, 6<<((idx % 4)*3) );
	    	buf[ q ] = 6;
	    }
	    else {
//	        printf("m4 = %d:%x ", idx % 5, 4<<((idx % 4)*3) );
	        buf[ q ] = 4;
	    	}
	    q++;
	    n >>= 1;
	}
}

#define NUM_Leds 8
uint8_t dta[ 24 ];

void Display( uint32_t *Cols ) {
	for( int x=0; x<NUM_Leds; x++ ) {
	enc_NEO8( Cols[x], dta );
	sendSPIbufZT( dta );
	}
}

/*********************************************************************
 * @fn      main
 * @brief   Main program.
 * @return  none
***/

//  reverse GRB = BRG
#define Black   0x000000
#define White   0xFFFFFF
#define Red     0x000100
#define Green   0x000001
#define Blue    0x010000
#define Yellow  0x000102
#define Magenta 0x010100
#define Cyan    0x010001


uint32_t Col_Arr[ 10 ] = { Blue, Red, Green, White, Yellow, Magenta, Cyan, Black, Black, Black };

int main(void)
{
	uint8_t p = 0;
	uint32_t Colours[NUM_Leds]={Blue, Red, Green, Blue, Black, Magenta, Green, Red}; //, Yellow, Red, Green, Blue, Black, Green, White};
	uint32_t Clear[NUM_Leds]  ={ 0, 0, 0, 0, 0, 0, 0, 0 };  //  , 0, 0, 0, 0, 0, 0, 0 };

//	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_4);
	SystemCoreClockUpdate();
	Delay_Init();
	USART_Printf_Init(115200);
	printf("\n\n\n\nSystemClk = %d MHz\r\n",SystemCoreClock / 1000000);
	printf( "ChipID = CH3V%03x\r\n\n", DBGMCU_GetCHIPID() >> 20 );

	SPI_1Lines_HalfDuplex_Init();

	printf("\nSPI HOST Mode\n\n");

	Display( Clear );
	// Delay_Ms( 500 );

	while( 1 )
	{	/*** Step Forward ***/
		Delay_Ms( 150 );

		if( p < NUM_Leds ) {
			Colours[p] = Col_Arr[ p ];
			if( p ) Colours[p-1] = Black;
			p++;
		} else { p = 0;}

		Display( Colours );
		if( p == NUM_Leds) Delay_Ms( 3000 );
		Delay_Ms( 150 );
		Display( Clear );

		/*** Step Backward *** /
//		p = 0;
		Delay_Ms( 150 );

		if( p < NUM_Leds ) {
			Colours[ NUM_Leds-p-1 ] = Col_Arr[ p ];
			if( p ) Colours[NUM_Leds-p] = Black;
			p++;
		} else { p = 0;}

		Display( Colours );
		if( p == NUM_Leds) { Display( Clear ); Delay_Ms( 3000 ); }
		Delay_Ms( 150 );


		/***/

	}  //  end forever loop
}
